package com.banc.project.controller;

import com.banc.project.dao.Client;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;


@org.springframework.stereotype.Controller
public class WebClientController {

    // inject via application.properties
    @Value("${welcome.message}")
    private String message;

    private List<Client> clients ;

    @GetMapping("/")
    public String main(Model model) {
        model.addAttribute("message", message);
      //  model.addAttribute("tasks", tasks);

        return "welcome"; //view
    }

    // /hello?name=kotlin
    @GetMapping("/home")
    public String mainWithParam(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "welcome"; //view
    }

    @PostMapping("/addClient")
    public String addClient(@RequestParam(name = "name", required = false, defaultValue = "") String name,
                            @RequestParam("id") String id,
                            @RequestParam("phone") String phone,
                            @RequestParam("adress") String adress,
                            Model model) {
        System.out.println("addClient method ");
        Client clt = new Client(id,name,phone,adress);
        if (clients==null){
            clients = new ArrayList<Client>();
        }
        clients.add(clt);
        model.addAttribute("clients", clients);
        model.addAttribute("client", new Client());
       return "listClients"; //view
    }

    @GetMapping("/listClients")
    public String listClients(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);
        if (clients==null){
            clients = new ArrayList<Client>();
        }
        model.addAttribute("clients", clients);
        model.addAttribute("client", new Client());
        return "listClients"; //view
    }

}