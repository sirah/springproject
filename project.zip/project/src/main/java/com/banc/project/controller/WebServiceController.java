package com.banc.project.controller;

import com.banc.project.dao.Client;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;


@Controller
public class WebServiceController {

    // inject via application.properties
    @Value("${welcome.message}")
    private String message;

    private List<Client> clients = new ArrayList<Client>();
    @GetMapping("/aboutUS")
    public String listServices(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "aboutUS"; //view
    }

    @GetMapping("/exchangeRate")
    public String exchangeRate(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "exchangeRate"; //view
    }

}