/*document.addEventListener("DOMContentLoaded", function(event) {
 checkClientTableLenght();

});

function checkClientTableLenght(){
var oRows = document.getElementById('dataTable').getElementsByTagName('tr').length;
console.log("oRows : "+oRows)
if(oRows>1){
document.getElementById('dataTable').style.display = "block";
document.getElementById("deleteClient").style.display = "block";

}else{
document.getElementById('dataTable').style.display = "none";
document.getElementById("deleteClient").style.display = "none";
}
}

function addRow(tableID) {
        //validate form
        if(checkForm()){
         if(confirm('Are you sure you want to add it ')){
		var table = document.getElementById(tableID);

			var rowCount = table.rows.length;
			var row = table.insertRow(rowCount);

			var cell1 = row.insertCell(0);
			var element1 = document.createElement("input");
			element1.type = "checkbox";
			element1.name="chkbox[]";
			cell1.appendChild(element1);

			var cell2 = row.insertCell(1);
			var elementId = document.getElementById("id");
			console.log("elemnt value " + elementId.value)
			var text = document.createTextNode(elementId.value);
			cell2.appendChild(text);
		//	cell2.innerHTML = rowCount + 1;

			var cell3 = row.insertCell(2);
			var elementName = document.getElementById("name");
			console.log("elemnt value " + elementName.value)
			var text = document.createTextNode(elementName.value);
			cell3.appendChild(text);


			var cell4 = row.insertCell(3);
			var elementPhone = document.getElementById("phone");
			console.log("elemnt value " + elementPhone.value)
			var text = document.createTextNode(elementPhone.value);
			cell4.appendChild(text);

			var cell5 = row.insertCell(4);
			var elementAdress = document.getElementById("adress");
			console.log("elemnt value " + elementAdress.value)
			var text = document.createTextNode(elementAdress.value);
			cell5.appendChild(text);

			document.getElementById('dataTable').style.display = "block";
            document.getElementById("deleteClient").style.display = "block";


		}

	 // send data to the server
		 ajaxSender();

	//reset input after adding client
	 document.getElementById("reset").click()


}
		}

function deleteRow(tableID) {
		if(confirm('Are you sure you want to delete this client ')){
				try {
			var table = document.getElementById(tableID);
			var rowCount = table.rows.length;

			for(var i=0; i<rowCount; i++) {
				var row = table.rows[i];
				var chkbox = row.cells[0].childNodes[0];
				if(null != chkbox && true == chkbox.checked) {
					table.deleteRow(i);
					rowCount--;
					i--;
				}


			}
			}catch(e) {
				alert(e);
			}
		}

		 checkClientTableLenght()

		}

function checkForm(){

    var  id  = document.getElementById("id").value;
    var  name  = document.getElementById("name").value;
    var  phone  = document.getElementById("phone").value;
    var  adress  = document.getElementById("adress").value;

    if ( id == ""){
    alert(" the ID must be filled out");
    return false;
    }else if(name == ""){
     alert(" the name must be filled out");
        return false;
    }else if(phone == ""){
     alert(" the phone must be filled out");
        return false;
    }else if(adress == ""){
     alert(" the email must be filled out");
        return false;
    }else if(!adress.includes("@") || !adress.includes(".")){
      alert(" the email must be filled correctly");
    } else return true;

}

*/
function ajaxSender(){
console.log(" ajaxSender method");
var url = 'http://localhost:8080/addClient';
var id = document.getElementById("id").value;
var client ={}
client.id = document.getElementById("id").value;
client.name = document.getElementById("name").value;
client.phone = document.getElementById("phone").value;
client.adress = document.getElementById("adress").value;

var json = JSON.stringify(client);

var xmlhttp = new XMLHttpRequest();
xmlhttp.open('POST', url, true);
xmlhttp.setRequestHeader('Content-type', 'application/json;charset=utf-8');
xmlhttp.onload = function() {
var result = JSON.parse(xmlhttp.responseText);
if(xmlhttp.status == "200"){
console.log(" succes")
}
else{
console.log(" failure ")
}
}
xmlhttp.send(json);

}