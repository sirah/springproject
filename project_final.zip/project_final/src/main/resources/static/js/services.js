
document.addEventListener("DOMContentLoaded", function(event) {

 //https://exchangeratesapi.io/
 var request = new XMLHttpRequest()
 request.open('GET', 'https://api.exchangeratesapi.io/latest', true)
 request.onload = function() {
   // Begin accessing JSON data here
   var data = JSON.parse(this.response)

   if (request.status >= 200 && request.status < 400) {

    //base rate
  var baseRate = data.base;

    //date rate
   document.getElementById('rateDateValue').innerHTML = data.date;
  //display pararhraph of date rate
 document.getElementById("displayRate").style.display = "block";
 // Find a <table> element with id="myTable":
 var table = document.getElementById("rateTable");

 //empty table after each research
 table.innerHTML = "";

 // add header table
  var row = table.insertRow(0)
  row.insertCell(0).innerHTML = "From currency";
  row.insertCell(1).innerHTML = "To currency";
  row.insertCell(2).innerHTML = "Rate in EURO";

  var index = 1;

 Object.keys(data.rates).forEach(function(key) {
   console.table('Key : ' + key + ', Value : ' + data.rates[key]+ 'index value : '+ index)
   // Create an empty <tr> element and add it to the 1st position of the table:
   var row = table.insertRow(index);
   var cell1 = row.insertCell(0);
   var cell2 = row.insertCell(1);
   var cell3 = row.insertCell(2);
   // Add some text to the new cells:
   cell1.innerHTML = key;
   cell2.innerHTML = baseRate;
   cell3.innerHTML = data.rates[key];
   index++;
 })
    } else {
     console.log('error')
   }
 }

 request.send()

});



function getDatafromAPI(){

//https://exchangeratesapi.io/
var request = new XMLHttpRequest()
var dateRate =  document.getElementById('rateDate').value;
console.log("date rate : "+ dateRate)
//request.open('GET', 'https://api.exchangeratesapi.io/2010-01-12', true)
request.open('GET', 'https://api.exchangeratesapi.io/'+dateRate, true)
//request.open('GET', 'https://api.exchangeratesapi.io/latest', true)
request.onload = function() {
  // Begin accessing JSON data here
  var data = JSON.parse(this.response)

  if (request.status >= 200 && request.status < 400) {

   //base rate
 var baseRate = data.base;

   //date rate
  document.getElementById('rateDateValue').innerHTML = data.date;
 //display pararhraph of date rate
document.getElementById("displayRate").style.display = "block";
// Find a <table> element with id="myTable":
var table = document.getElementById("rateTable");

//empty table after each research
table.innerHTML = "";

// add header table
 var row = table.insertRow(0)
 row.insertCell(0).innerHTML = "From currency";
 row.insertCell(1).innerHTML = "To currency";
 row.insertCell(2).innerHTML = "Rate in EURO";

 var index = 1;

Object.keys(data.rates).forEach(function(key) {
  console.table('Key : ' + key + ', Value : ' + data.rates[key]+ 'index value : '+ index)
  // Create an empty <tr> element and add it to the 1st position of the table:
  var row = table.insertRow(index);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  var cell3 = row.insertCell(2);
  // Add some text to the new cells:
  cell1.innerHTML = key;
  cell2.innerHTML = baseRate;
  cell3.innerHTML = data.rates[key];
  index++;
})
   } else {
    console.log('error')
  }
}

request.send()

}