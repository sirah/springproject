package com.banc.project.form;

public class ClientForm {
	
	   
	   private String Name;
	   private String Phone;
	   private String Adress ;
	   private String ID;
	   
	   public String getName() {
			return Name;
		}
		public void setName(String name) {
			Name = name;
		}
	    
	   public String getPhone() {
			return Phone;
		}
		public void setPhone(String phone) {
			Phone = phone;
		}
		public String getAdress() {
			return Adress;
		}
		public void setAdress(String adress) {
			Adress = adress;
		}
		public String getID() {
			return ID;
		}
		public void setID(String id) {
			ID = id;
		}

	public ClientForm() {
	}
}
