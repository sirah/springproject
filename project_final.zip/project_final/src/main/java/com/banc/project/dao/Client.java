package com.banc.project.dao;

public class Client {
   private String ID;
   private String Name;
   private String Phone;
   private String Adress ;

   public Client(String id, String name, String phone, String adress) {
     super();
      ID = id;
      Name = name;
      Phone = phone;
      Adress = adress;
   }

	public String getID() {
		return ID;
	}
	public void setID(String id) {
		ID = id;
	}

   public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
    
   public String getPhone() {
		return Phone;
	}
	public void setPhone(String phone) {
		Phone = phone;
	}
	public String getAdress() {
		return Adress;
	}
	public void setAdress(String adress) {
		Adress = adress;
	}

}
