package com.banc.project.controller;

import com.banc.project.dao.Client;
import com.banc.project.form.ClientForm;



import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


@Controller
public class WebClientController {

	private static List<Client> clients = new ArrayList<Client>();

	@Value("${welcome.message}")
	private String message;

	@Value("${error.message}")
	private String errorMessage;

	@Value("${remove.message}")
	private String removeMessage;

	@Value("${client.notFound.message}")
	private String removeMessageClientNotFound;

	@Value("${edit.message}")
	private String editMessage;
	
	@RequestMapping(value = { "/" }, method = RequestMethod.GET)
	public String welcome(Model model) {
		model.addAttribute("message", message);
		return "welcome";
	}

	

	@RequestMapping(value = { "/listClients" }, method = RequestMethod.GET)
	public String listClients(Model model) {
		model.addAttribute("clients", clients );
		return "welcome";
	}

	@RequestMapping(value = { "/listClients2" }, method = RequestMethod.GET)
	public String listClients2(Model model) {
		model.addAttribute("clients", clients );
		return "listClients2";
	}

	@RequestMapping(value = { "/addClient" }, method = RequestMethod.GET)
	public String showAddClientPage(Model model) {
		ClientForm clientForm = new ClientForm();
		model.addAttribute("clientForm", clientForm);
		return "addClient";
	}

	@RequestMapping(value = { "/addClient" }, method = RequestMethod.POST)
	public String saveClient(Model model, @ModelAttribute("clientForm") ClientForm clientForm) {
		String ID = clientForm.getID();
		String cName = clientForm.getName();
		String cPhone = clientForm.getPhone();
		String cAdress = clientForm.getAdress();
		if (ID != null && ID.length() > 0 && cName != null && cName.length() > 0 && cPhone != null
				&& cPhone.length() > 0 && cAdress != null && cAdress.length() > 0) {
			Client newClient = new Client(ID, cName, cPhone, cAdress);
			clients.add(newClient);
			model.addAttribute("clients", clients);
			model.addAttribute("client", new ClientForm());
			return "listClients2";
		}else{
			model.addAttribute("client", new ClientForm());
			model.addAttribute("errorMessage", errorMessage);
			 return "addClient";
		}

	}


	@RequestMapping(value = { "/editClient" }, method = RequestMethod.GET)
	public String showEditClientPage(Model model) {
		List<Client> client = new ArrayList<>();
		model.addAttribute("clients", clients);
		ClientForm clientForm = new ClientForm();
		model.addAttribute("clientForm", clientForm);
		clients.iterator().forEachRemaining(client::add);
		model.addAttribute("form", new ClientCreationDto(client));
		model.addAttribute("editMessage", editMessage);

		return "editClient";
	}

	@RequestMapping(value = "/editClient",method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE)
	@ResponseBody
	public List<Client> updateClient(@RequestBody Client client) {
		System.out.println("(Service Side) Editing client: " + client.getID());
		String ID = client.getID();
		Boolean clientfound = false;
		if (ID != null && ID.length() > 0) {
			Iterator<Client> iter = clients.iterator();
			while (iter.hasNext()) {
				Client clientToDelete = iter.next();
				String IDNo = clientToDelete.getID();
				if (IDNo.equals(ID)) {
					iter.remove();
				}
			}
		}
		clients.add(client);
		return clients;

	}

	@RequestMapping(value = { "/deleteClient" }, method = RequestMethod.GET)
	public String showDeleteClientPage(Model model) {
		ClientForm clientForm = new ClientForm();
		model.addAttribute("clientForm", clientForm);
		return "deleteClient";
	}

	@RequestMapping(value = { "/deleteClient" }, method = RequestMethod.POST)
	public String removeClient(Model model, @ModelAttribute("clientForm") ClientForm clientForm) {
//	public String removeClient(Model model, @PathVariable String ID) {
		String ID = clientForm.getID();
		Boolean clientfound = false;
		if (ID != null && ID.length() > 0) {
			Iterator<Client> iter = clients.iterator();
			while (iter.hasNext()) {
				Client client = iter.next();
				String IDNo = client.getID();
				if (IDNo.equals(ID)) {
					int idx = clients.indexOf(client);
					//clients.remove(idx);
					clientfound = true;
					iter.remove();
				}
			}
		}
		model.addAttribute("clients", clients);
		if(clientfound){
			model.addAttribute("removeMessage", removeMessage);
		}else {
			model.addAttribute("removeMessage", removeMessageClientNotFound);
		}

		return "listClients2";
	}


	@RequestMapping(value = { "/searchClient" }, method = RequestMethod.POST)
	public String searchlient(Model model, @ModelAttribute("clientForm") ClientForm clientForm) {
//	public String removeClient(Model model, @PathVariable String ID) {
		String ID = clientForm.getID();
		Boolean clientfound = false;
		if (ID != null && ID.length() > 0) {
			Iterator<Client> iter = clients.iterator();
			while (iter.hasNext()) {
				Client client = iter.next();
				String IDNo = client.getID();
				if (IDNo.equals(ID)) {
					model.addAttribute("client", client);
					clientfound = true;
					break;
				}
			}
		}

		if(!clientfound){
		 model.addAttribute("removeMessage", removeMessageClientNotFound);
		}
		model.addAttribute("clientfound", clientfound);
		model.addAttribute("clientsearched", true);
		model.addAttribute("clients", clients);
		return "editClient";
	}
}