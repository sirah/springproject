package com.banc.project.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.banc.project.dao.Client;



public class ClientCreationDto {

	@Autowired
	private List<Client> clients;

	public ClientCreationDto() {
		this.clients = new ArrayList<>();
	}

	public ClientCreationDto(List<Client> client) {
		this.clients = client ;
	}

	public void addClient(Client client) {
		this.clients.add(client);
	}

	public List<Client> getClients() {
		return clients;
	}

	public void setClients(List<Client> clients) {
		this.clients = clients;
	}
}
