package com.banc.project.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
public class WebServiceController {

    // inject via application.properties
    @Value("${welcome.message}")
    private String message;


    @GetMapping("/welcome")
    public String listHome(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "welcome"; //view
    }
    

    @GetMapping("/aboutUS")
    public String listServices(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "aboutUS"; //view
    } 

    
    
    
    @GetMapping("/exchangeRate")
    public String exchangeRate(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "exchangeRate"; //view
    }
    
    @GetMapping("/pageInformations")
    public String pageInformations(
            @RequestParam(name = "name", required = false, defaultValue = "") String name, Model model) {

        model.addAttribute("message", name);

        return "pageInformations"; //view
    }

}