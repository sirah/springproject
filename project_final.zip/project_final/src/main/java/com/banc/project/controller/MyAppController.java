package com.banc.project.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class MyAppController {

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	 
	 public String getMappingLog() {
		 	logger.trace("There is a TRACE-Message");
			logger.debug("This is a DEBUG-Message");
			logger.info("This is a INFO-Message");
			logger.warn("This is a WARN-Message");
			logger.error("This is a ERROR-Message");
			return "index.html";
	 }
	
	@RequestMapping(path = "/logging", method = RequestMethod.GET)
	@ResponseBody
	public String getMapping() {
		
		String result =
				"<!DOCTYPE html>\r\n" + 
				"<html xmlns:th=\"http//www.thymeLeaf.org\">\r\n" + 
				"<head>\r\n" + 
				"<link rel=\"stylesheet\" type=\"text/css\" href=\"/CSS/Main.css\"\r\n" + 
				"th:href=\"@{/CSS/Main.css}\">"+
				"<title>Welcome to Our Paradise</title>\r\n" + 
				"</head>\r\n" + 
				"<body>\r\n" +
				"<header id=\"Header\">\r\n" + 
				"  <h1 style=\"color: black;\"><font size=\"8\">  Banc Stuff </font> \r\n" + 
				"  \r\n" + 
				"	<img id=\"Header-r\" src=\"/images/bank.jpg\"  height=\"100px\" width=\"100px\" alt=\"Das Bild ist nicht verfügbar\"> \r\n" + 
				"</h1> \r\n" + 
				"</header>"+
				"\r\n" + 
				"<article id=\"Article\">"+
				"<h1>Werkstück A\n" +  
				"\r\n" + 
				"<p>Hallo Client</p>\r\n" +  
				"\r\n" + 
				"<a href= /FormTester>Beitreten</a>\r\n" +
				"</h1> </article>"+
				"</body>\r\n" + 
				"</html> ";
		return result;
	}
}
