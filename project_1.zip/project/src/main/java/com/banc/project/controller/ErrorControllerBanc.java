package com.banc.project.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class ErrorControllerBanc implements ErrorController {

    private static final String PATH = "/error";

    @RequestMapping(value = PATH)
    public ModelAndView error() {
        System.out.println("error controller");

        ModelAndView errorPage = new ModelAndView("error");

        return errorPage;
    }

    @Override
    public String getErrorPath() {
        return PATH;
    }
}